# Landing Zone Creation

The purpose of this repository is to provide an automation to deploy the components needed to create a landing zone.

Currently, this includes
- An Azure [subscription] with cost-center [tags]
- (Only in `mg-corp`) A network [resource group] that hosts a [virtual network] that is [peered] to the central Hub
- Two [recovery services vaults] alongside a [policy-] & [role-assignment] for the locations `West Europe` & `North Europe` respectively

![PipelineSelect](docs/deploymentOverview.png =60%x)

## Usage

Fundamentally, there are two paths you can take to deploy the landing zone:
- By updating the `appsettings.json` configuration file in the main branch (will automatically trigger the pipeline).
  > ***NOTE:*** Save & commit the file ONLY after you entered all the details, not half way through
- By triggering the `acd-automation-addSubscription` pipeline and providing all required parameters in the opening form

### Option 1: Manually updating the [appsettings.json]
You can start the creation process by updating the `appsettings.json` in branch `main` either within the web interface or with an git enabled editor (such as VSCode).

Example JSON:
```json
{
  "ProjectName": "cs",
  "Stage": "test",
  "MgmtGrId": "mg-corp",
  "VNETAddressPrefix": "10.227.34.0/24",
  "Tag": {
    "ApplicationName": "cs",
    "billing_entity_name": "Customer SE & Co. oHG",
    "billing_entity_additional_info_optional": "IT-Einkauf",
    "billing_entity_street": "Musterstr. 60",
    "billing_entity_postalcode": 45318,
    "billing_entity_city": "Essen",
    "billing_entity_country": "Germany",
    "billing_invoice_recipient_unit": "ATS / Technology Platform Solutions",
    "billing_invoice_recipient_contact": "Christian Scholz",
    "billing_invoice_recipient_contact_email": "max.mustermann@customer.de"
  }
}
```

### Option 2: Directly triggering the [acd-automation-addSubscription] pipeline

You can also start the [acd-automation-addSubscription pipeline](https://dev.azure.com/an-de-ohg-sbi/AN-Azure-ControlRepo/_build?definitionId=66) directly. In this case, the `appsettings.json` is only created as an artifact attached to the pipeline run. The file in the repository itself remains as is.

![PipelineSelect](docs/pipelineSelect.png =80%x)

Within an opening web interface you can fill in any required details based on the values from the Landing Zone Request form.

> *NOTE:* Ensure the `Branch/Tag` is set to `main`\
> *NOTE:* Ensure there are no whitespaces in front of the text you enter

![PipelineTrigger](docs/pipelineTrigger.png =25%x)