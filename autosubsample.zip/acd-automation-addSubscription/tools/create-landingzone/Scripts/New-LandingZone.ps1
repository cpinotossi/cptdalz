
<#
    .SYNOPSIS
    Creates Landing Zone

    .DESCRIPTION
    Creates Landing zone. Includes Validations / Sanity Checks against Azure

    .PARAMETER AppSettingsPath
    Mandatory. The appsettings.json with the fundamental deployment configuration (e.g. Project & Stage)

    .PARAMETER virtualNetworks
    Optional. The virtual networks to create

    .EXAMPLE
    ./tools/Scripts/New-LandingZone.ps1 -AppSettingsPath:"appsettings.json" -WhatIf:$true
#>
[CmdletBinding(SupportsShouldProcess)]
param(
    [Parameter(Mandatory = $true)]
    [string] $AppSettingsPath
)

#region helper functions
<#
.SYNOPSIS
Check the provided list of address prefixes regarding their structure and availability

.DESCRIPTION
Check the provided list of address prefixes regarding their structure and availability

.PARAMETER AddressPrefixes
Mandatory. The address prefixes to check

.PARAMETER newVnetRGName
Mandatory. The name of the rg of the VNET to be created

.PARAMETER newVnetName
Mandatory. The name of the VNET to be created

.EXAMPLE
Confirm-VNETAddressPrefix -AddressPrefixes @('192.167.153.1/24')
#>
function Confirm-VNETAddressPrefix {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string[]] $AddressPrefixes,

        [Parameter(Mandatory = $false)]
        [string] $newVnetRGName,

        [Parameter(Mandatory = $false)]
        [string] $newVnetName,

        [Parameter(Mandatory = $false)]
        [string] $existingSubscriptionId
    )

    $foundErrors = 0

    # Warning: Only works with subscriptions the principal has READ access to
    Write-Verbose "Fetch all existing VNETs the principal has access to"
    $existingVNETs = [System.Collections.ArrayList]@()
    $currentSubscriptionId = (Get-AzContext).Subscription.Id # Current subscription to return to
    foreach ($subscription in (Get-AzSubscription | Where-Object { $_.State -eq 'Enabled' })) {
        Set-AzContext -Subscription $subscription 
        $existingVNETs += Get-AzVirtualNetwork
    }            
    Set-AzContext -Subscription $currentSubscriptionId

    ## Validate
    # Address space
    foreach ($addressPrefix in $AddressPrefixes) {

        # Check format
        if ($addressPrefix -notmatch '^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/[0-9]{1,2}$') {
            Write-Error ('Address space [{0}] of virtual network [{1}] is not valid' -f $addressPrefix, $virtualNetwork.name) -ErrorAction 'Continue'
            $foundErrors++
        }

        # Check if already used - Overlaps are ignored for now
        if ((-not [String]::IsNullOrEmpty($existingSubscriptionId)) -and $existingVNETs.id -contains ('/subscriptions/{0}/resourceGroups/{1}/providers/Microsoft.Network/virtualNetworks/{2}' -f $existingSubscriptionId, $newVnetRGName, $newVnetName)) {
            Write-Verbose "Allowing VNET [$newVnetRGName|$newVnetName] of subscription [$existingSubscriptionId] as it is the one we deploy." -Verbose
        }
        else {
            foreach ($existingVNET in $existingVNETs) {
                if ($existingVNET.AddressSpace.AddressPrefixes -contains $addressPrefix) {
                    Write-Error ('Address space [{0}] for virtual network [{1}|{2}] is already used by virtual network [{3}]' -f $addressPrefix, $newVnetRGName, $newVnetName, $existingVNET.Id) -ErrorAction 'Continue'
                    $foundErrors++
                }
            }     
        }
    }

    if ($foundErrors -gt 0) {
        throw "Found [{$foundErrors}] issues with the configured virtual networks. Please examine raised errors."
    }

    Write-Verbose "Address prefix [$addressPrefix] is valid"
}
#endregion

#Read Config
$Config = Get-Content -Raw -Path $AppSettingsPath | ConvertFrom-Json -Depth 99 -AsHashtable

$project = $Config.ProjectName.ToLower()
$stage = $Config.Stage.ToLower()

Write-Verbose "Processing Config: " -Verbose
Write-Verbose ($Config | ConvertTo-Json) -Verbose

#Build Subscription Name
# As soon as we integrate update of existing subscriptions, we could get rid of it and leave the check up to bicep / SubscriptionAlias
$SubscriptionName = "sub-" + $project + "-" + $stage

# Set the Build Title in Azure DevOps, so we see straight what that run is about
if (-not $WhatIfPreference) {
    $BuildTitle = "$($SubscriptionName) - $($Env:BUILD_BUILDNUMBER)"
}
else {
    $BuildTitle = "Validate $($SubscriptionName) - $($Env:BUILD_BUILDNUMBER)"
}
Write-Host "##vso[build.updatebuildnumber]$BuildTitle"

#region Sanity Checks

# Subscription validation
# -----------------------
# Check if Sub already exists and get ID if
$ExistingSubscriptionId = (Get-AzSubscription -SubscriptionName $SubscriptionName -ErrorAction 'Ignore').id
if (-not $ExistingSubscriptionId) {
    $ExistingSubscriptionId = (Get-AzSubscriptionAlias -AliasName $SubscriptionName -WhatIf:$false -ErrorAction 'Ignore').id
}
if (-not $ExistingSubscriptionId) {
    $ExistingSubscriptionId = (Get-AzSubscriptionAlias -AliasName "alias-$SubscriptionName" -WhatIf:$false -ErrorAction 'Ignore').id
}
if ($ExistingSubscriptionId) {
    Write-Verbose "Found subscription [$SubscriptionName]" -Verbose
}

# Address Prefix validation
# -------------------------
$confirmInputObject = @{
    AddressPrefixes = $Config.vnetAddressPrefix
    Verbose         = $true 
    ErrorAction     = 'Stop'
}
if (-not [String]::IsNullOrEmpty($ExistingSubscriptionId)) {
    $confirmInputObject += @{
        newVnetRGName          = 'rg-{0}-{1}-vnet' -f $project, $stage
        newVnetName            = 'vnt-weu-{0}-{1}' -f $stage, $project
        existingSubscriptionId = $ExistingSubscriptionId
    }
}
$null = Confirm-VNETAddressPrefix @confirmInputObject
#endregion Sanity Checks

# Deploy template for LZ
# ----------------------

$TemplateParameterObject = @{
    MgmtGrId                = $Config.MgmtGrId
    ProjectName             = $project
    Stage                   = $stage
    VNETAddressPrefix       = $Config.vnetAddressPrefix
    Tags                    = $config.Tag
    subscriptionAlias       = "alias-$SubscriptionName"
    subscriptionDisplayName = $SubscriptionName
}
if ($ExistingSubscriptionId) {
    $TemplateParameterObject['ExistingSubscriptionID'] = $ExistingSubscriptionId
}

$DeploymentParams = @{
    DeploymentName          = "LZ-$(-join (Get-Date -Format yyyyMMddTHHMMssffffZ)[0..63])"
    ManagementGroupId       = $Config.MgmtGrId
    TemplateFile            = "$PSScriptRoot/../deploy.bicep"
    location                = "westeurope"
    TemplateParameterObject = $TemplateParameterObject 
    Verbose                 = $true
}

Write-Verbose "Invoke deployment with" -Verbose
Write-Verbose ($DeploymentParams | ConvertTo-Json | Out-String) -Verbose

Test-AzManagementGroupDeployment @DeploymentParams 

if ($PSCmdlet.ShouldProcess("Management-group-level deployment for subscription [$SubscriptionName]", "Invoke")) {
    $res = New-AzManagementGroupDeployment @DeploymentParams
    Write-Verbose ($res.Outputs | ConvertTo-Json -Depth 10 | Out-String) -Verbose
}
else {
    New-AzManagementGroupDeployment @DeploymentParams -WhatIf
}